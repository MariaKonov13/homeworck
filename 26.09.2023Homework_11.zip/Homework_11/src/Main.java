public class Main {
    public static void main(String[] args) {
        System.out.println("Я изучаю");
        System.out.println("Java");
        System.out.println("так "+3+" раза ура");
        System.out.printf("так %d раза %s ",3, "ура");
    }
}