public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        char c = 'G';
        System.out.println(c);
        int x = 89;
        System.out.println(x);
        byte b = 4;
        System.out.println(b);
        short s = 56;
        System.out.println(s);
        float f = 4.7333436F;
        System.out.println(f);
        double d = 4.355453532;
        System.out.println(d);
        long l = 12121;
        System.out.println(l);

    }
}