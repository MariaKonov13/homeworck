public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        int number1 = 345;
        int n1 = number1 / 100;
        int n2 = number1  % 100 / 10;
        int n3 = number1 % 10;
        System.out.println(n1);
        System.out.println("Число " + number1 + " -> " + n1 + ", " + n2 + ", " + n3);


        int number2 = 987;
        int n4 = number2 / 100;
        int n5 = number2  % 100 / 10;
        int n6 = number2 % 10;
        System.out.println(n1);
        System.out.println("Число " + number2 + " -> " + n4 + ", " + n5 + ", " + n6);


    }
}